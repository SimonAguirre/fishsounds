# -*- coding: utf-8 -*-
"""
Created on Sat May 27 00:52:20 2023

@author: Simon
"""
import os

class Config:
    def __init__(self, mode='conv', nfilt=15, nfeat=13,
                 nfft=512, rate=8000, hfreq=4000):
        self.mode = mode
        self.nfilt = nfilt
        self.nfeat = nfeat
        self.nfft = nfft
        self.rate = rate
        self.hfreq = hfreq
        self.step = int(rate/10)
        self.model_path = os.path.join('models', mode + ".model")
        self.p_path = os.path.join('pickles', mode + ".p")